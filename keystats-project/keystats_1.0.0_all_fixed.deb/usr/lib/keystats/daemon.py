#!/usr/bin/env python3
"""
keystats-daemon - Lightweight keyboard statistics daemon.
Listens to Linux input events via evdev and counts keypresses.
"""

import os
import sys
import time
import signal
import select
import logging
import errno
from pathlib import Path

# Setup logging to file
LOG_DIR = "/var/log/keystats"
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(LOG_DIR, "daemon.log")),
    ]
)
logger = logging.getLogger("keystats")

# Suppress stderr in daemon mode (after fork)
class NullDevice:
    def write(self, s): pass
    def flush(self): pass


class KeyStatsDaemon:
    """Main daemon class for counting keyboard events."""

    # evdev key event types
    EV_KEY = 1
    # Key value codes
    KEY_PRESS = 1      # Key pressed
    KEY_RELEASE = 0    # Key released
    KEY_REPEAT = 2     # Key held (auto-repeat)

    def __init__(self):
        self.running = False
        self.devices = []
        self.epoll = None
        self.key_buffer = 0
        self.last_flush = time.time()
        self.flush_interval = 10  # Flush to DB every 10 seconds

    def find_keyboard_devices(self):
        """
        Find all keyboard input devices from /dev/input/.
        Returns list of device paths.
        """
        devices = []
        input_dir = Path("/dev/input")

        if not input_dir.exists():
            logger.error("/dev/input directory not found")
            return devices

        # Method 1: Use /proc/bus/input/devices to find keyboards
        try:
            with open("/proc/bus/input/devices", "r") as f:
                content = f.read()

            handlers = []
            current_handlers = []
            is_keyboard = False

            for line in content.split("\n"):
                line = line.strip()
                if line.startswith("I:"):
                    is_keyboard = False
                    current_handlers = []
                elif line.startswith("H:") and "kbd" in line.lower():
                    is_keyboard = True
                    # Extract handler numbers
                    handler_part = line.split("=")[1] if "=" in line else ""
                    for h in handler_part.split():
                        if h.startswith("event"):
                            current_handlers.append(h)
                elif line == "":
                    if is_keyboard and current_handlers:
                        handlers.extend(current_handlers)
                    is_keyboard = False
                    current_handlers = []

            for handler in handlers:
                dev_path = f"/dev/input/{handler}"
                if os.path.exists(dev_path):
                    devices.append(dev_path)

        except Exception as e:
            logger.warning(f"Could not read /proc/bus/input/devices: {e}")

        # Method 2: Fallback - scan /dev/input/event* and test
        if not devices:
            logger.info("Falling back to scanning /dev/input/event*")
            try:
                for event_dev in sorted(input_dir.glob("event*")):
                    try:
                        fd = os.open(str(event_dev), os.O_RDONLY | os.O_NONBLOCK)
                        # Try to read capability bits to check if it's a keyboard
                        import fcntl
                        import struct

                        # EVIOCGBIT - get event bits
                        EVIOCGBIT = 0x80004520 + 0x01  # _IOC(_IOC_READ, 'E', 0x20 + type, len)
                        buf = bytearray(64)
                        try:
                            fcntl.ioctl(fd, EVIOCGBIT, buf)
                            # Check if EV_KEY bit is set (bit 1)
                            if buf[0] & 0x02:
                                devices.append(str(event_dev))
                        except:
                            pass
                        os.close(fd)
                    except (PermissionError, OSError):
                        continue
            except Exception as e:
                logger.warning(f"Fallback scanning failed: {e}")

        # Method 3: Last resort - just try all event devices
        if not devices:
            logger.info("Trying all event devices")
            try:
                for event_dev in sorted(input_dir.glob("event*")):
                    if os.access(str(event_dev), os.R_OK):
                        devices.append(str(event_dev))
            except Exception as e:
                logger.warning(f"Event device listing failed: {e}")

        # Remove duplicates while preserving order
        seen = set()
        unique_devices = []
        for d in devices:
            if d not in seen:
                seen.add(d)
                unique_devices.append(d)

        logger.info(f"Found {len(unique_devices)} keyboard device(s): {unique_devices}")
        return unique_devices

    def open_devices(self):
        """Open all keyboard devices and add to epoll."""
        import selectors

        self.epoll = selectors.EpollSelector()

        for dev_path in self.find_keyboard_devices():
            try:
                fd = os.open(dev_path, os.O_RDONLY | os.O_NONBLOCK)
                self.devices.append({
                    'fd': fd,
                    'path': dev_path,
                    'buffer': b'',
                })
                self.epoll.register(fd, selectors.EVENT_READ)
                logger.info(f"Opened device: {dev_path}")
            except PermissionError:
                logger.error(
                    f"Permission denied on {dev_path}. "
                    "Ensure the keystats user has access to input group."
                )
            except OSError as e:
                logger.warning(f"Could not open {dev_path}: {e}")

        if not self.devices:
            logger.error("No keyboard devices could be opened!")
            return False
        return True

    def read_events(self, device):
        """
        Read input events from a device.
        Linux input_event structure:
            struct input_event {
                struct timeval time;  // 16 bytes (2x long on 64-bit)
                __u16 type;           // 2 bytes
                __u16 code;           // 2 bytes
                __s32 value;          // 4 bytes
            };  // Total: 24 bytes
        """
        import struct

        INPUT_EVENT_SIZE = 24

        try:
            while True:
                chunk = os.read(device['fd'], INPUT_EVENT_SIZE * 64)
                if not chunk:
                    break
                device['buffer'] += chunk

                # Process complete events
                while len(device['buffer']) >= INPUT_EVENT_SIZE:
                    event_data = device['buffer'][:INPUT_EVENT_SIZE]
                    device['buffer'] = device['buffer'][INPUT_EVENT_SIZE:]

                    # Unpack the event (skip time bytes, we don't need them)
                    # Format: QQHHl (2 unsigned long long, 2 unsigned short, 1 int)
                    # But we only care about type, code, value at offsets 16, 18, 20
                    _, ev_type, ev_code, ev_value = struct.unpack_from(
                        "<QHHi", event_data, offset=8
                    )

                    # Only count actual key presses (not releases or repeats)
                    if ev_type == self.EV_KEY and ev_value == self.KEY_PRESS:
                        self.key_buffer += 1

        except OSError as e:
            if e.errno == errno.EAGAIN or e.errno == errno.EWOULDBLOCK:
                pass  # No more data available
            else:
                logger.warning(f"Error reading from {device['path']}: {e}")

    def flush_buffer(self):
        """Flush buffered keypresses to database."""
        if self.key_buffer > 0:
            count = self.key_buffer
            self.key_buffer = 0
            try:
                from db import increment_keypress
                for _ in range(count):
                    increment_keypress()
                logger.debug(f"Flushed {count} keypresses to database")
            except Exception as e:
                logger.error(f"Failed to flush to database: {e}")

    def signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully."""
        logger.info(f"Received signal {signum}, shutting down...")
        self.running = False

    def daemonize(self):
        """Detach from terminal and run as a proper daemon."""
        # First fork
        try:
            pid = os.fork()
            if pid > 0:
                sys.exit(0)
        except OSError as e:
            logger.error(f"First fork failed: {e}")
            sys.exit(1)

        # Decouple from parent environment
        os.chdir("/")
        os.setsid()
        os.umask(0)

        # Second fork
        try:
            pid = os.fork()
            if pid > 0:
                sys.exit(0)
        except OSError as e:
            logger.error(f"Second fork failed: {e}")
            sys.exit(1)

        # Redirect standard file descriptors to /dev/null
        sys.stdout.flush()
        sys.stderr.flush()

        with open("/dev/null", "r") as f:
            os.dup2(f.fileno(), sys.stdin.fileno())
        with open("/dev/null", "a+") as f:
            os.dup2(f.fileno(), sys.stdout.fileno())
            os.dup2(f.fileno(), sys.stderr.fileno())

        # Write PID file
        pid_dir = "/var/run"
        if os.access(pid_dir, os.W_OK):
            with open(os.path.join(pid_dir, "keystats.pid"), "w") as f:
                f.write(str(os.getpid()))

        logger.info(f"Daemon started with PID {os.getpid()}")

    def run(self, daemon_mode=True):
        """Main daemon loop."""
        if daemon_mode:
            self.daemonize()

        # Setup signal handlers
        signal.signal(signal.SIGTERM, self.signal_handler)
        signal.signal(signal.SIGINT, self.signal_handler)
        signal.signal(signal.SIGHUP, lambda s, f: None)  # Ignore SIGHUP

        # Initialize database
        try:
            from db import init_db
            init_db()
            logger.info("Database initialized")
        except Exception as e:
            logger.error(f"Failed to initialize database: {e}")
            sys.exit(1)

        # Open keyboard devices
        if not self.open_devices():
            logger.error("No devices available, exiting")
            sys.exit(1)

        logger.info("KeyStats daemon running")
        self.running = True

        try:
            while self.running:
                # Wait for events with timeout
                events = self.epoll.select(timeout=1.0)

                for key, mask in events:
                    for device in self.devices:
                        if device['fd'] == key.fd:
                            self.read_events(device)
                            break

                # Periodic flush to database
                now = time.time()
                if now - self.last_flush >= self.flush_interval:
                    self.flush_buffer()
                    self.last_flush = now

        except Exception as e:
            logger.exception("Fatal error in main loop")
        finally:
            self.shutdown()

    def shutdown(self):
        """Clean up resources."""
        self.running = False
        self.flush_buffer()

        # Close all devices
        for device in self.devices:
            try:
                os.close(device['fd'])
            except:
                pass
        self.devices = []

        if self.epoll:
            self.epoll.close()

        # Remove PID file
        pid_file = "/var/run/keystats.pid"
        if os.path.exists(pid_file):
            try:
                os.remove(pid_file)
            except:
                pass

        logger.info("KeyStats daemon stopped")


def main():
    """Entry point."""
    daemon_mode = "--foreground" not in sys.argv

    if "--help" in sys.argv or "-h" in sys.argv:
        print("Usage: keystats-daemon [--foreground]")
        print("  --foreground  Run in foreground (don't daemonize)")
        sys.exit(0)

    daemon = KeyStatsDaemon()
    daemon.run(daemon_mode=daemon_mode)


if __name__ == "__main__":
    main()
